﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Net;
using System.Text;
using System.Threading;
using dotNetClassLibrary;
namespace TimedPinger
{
    internal class Pinger
    {
        static void Main(string[] args)
        {
            try
            {
                Thread listener = new Thread(new ThreadStart(listenForACK));
                listener.Start();
                
                byte[] sendBytes;
                uint count = 0;
                Console.WriteLine("Enter the IP of where you would like to send a message:");

                //recipient address and port
                IPAddress broadcast = IPAddress.Parse(Console.ReadLine());
                IPEndPoint endpoint = new IPEndPoint(broadcast, 12000);

                //the parameters are: specifies that communicates with ipv4, socket will use datagrams -- independent messages with udp  ,socket will use udp 
                Socket sock = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);

                while (true)
                {
                    sendBytes = ProcessContent.convertToTimestampedBytes(count, ';', "ping");
                    sock.SendTo(sendBytes, endpoint);
                    Console.WriteLine("Ping sent");
                    count++;
                    Thread.Sleep(1000);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred: " + ex.Message);
            }
        }

        public static void listenForACK()
        {
            Console.WriteLine("Listening on port 1543 for ack responses");
            UdpClient listener = new UdpClient(1543);
            IPEndPoint groupEP = new IPEndPoint(IPAddress.Any, 1543);
            while (true)
            {
                Console.WriteLine("entered while loop");
                byte[] bytes = listener.Receive(ref groupEP);
                Console.WriteLine("Things recieved.");
                if (Encoding.ASCII.GetString(bytes, 8, bytes.Length - 8).Equals("ack"))
                {
                    DateTime send = DateTime.FromBinary(BitConverter.ToInt64(bytes, 0));
                    double latencyMilliseconds = (DateTime.Now - send).Milliseconds;
                    Console.WriteLine($"ACK recieved from {groupEP.Address.ToString()}, " + latencyMilliseconds + "ms of latency");
                    ProcessContent.WriteToFile($"ACK recieved from {groupEP.Address.ToString()}, " + latencyMilliseconds + "ms of latency");

                }
                else
                {
                    Console.WriteLine("Invalid data sent to ack port.");
                }
            }
        }
    }
}
