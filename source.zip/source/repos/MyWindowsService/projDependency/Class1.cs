﻿namespace projDependency
{
    public class DependencyClass
    {
        public void DoSomething()
        {
            Console.WriteLine("DependencyClass is doing something...");
        }
    }
}
